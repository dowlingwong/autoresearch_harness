"""Bounded worker runtime interfaces."""

