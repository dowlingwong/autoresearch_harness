"""Control-plane lifecycle contracts."""

