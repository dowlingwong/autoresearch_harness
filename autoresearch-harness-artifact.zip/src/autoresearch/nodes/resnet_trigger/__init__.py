"""ResNet-trigger node integration."""

