"""Swappable manager interfaces."""

