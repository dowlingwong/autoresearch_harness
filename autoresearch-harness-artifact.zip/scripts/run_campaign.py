#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from autoresearch.control_plane.campaign import run_dry_campaign, run_real_campaign
from autoresearch.evaluation.campaign_summary import load_campaign_summary
from autoresearch.llm.langchain_client import LangChainProposalBackend
from autoresearch.llm.providers import resolve_worker_model_args
from autoresearch.memory.event_store import CampaignEventStore
from autoresearch.nodes.registry import load_registered_node
from autoresearch.reporting.export_tables import export_campaign_tables


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run a Stage 2 fixed-budget campaign.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Dry-run (no worker, mock metrics):
  python3 scripts/run_campaign.py \\
      --node resnet_trigger --campaign-id smoke --budget 3 --dry-run

Real campaign (ClawWorker drives the legacy loop with proposal-generated packets):
  python3 scripts/run_campaign.py \\
      --node resnet_trigger --campaign-id main \\
      --budget 15 --manager prompt_manager \\
      --memory-mode append_only_summary_with_rationale \\
      --node-root nodes/ResNet_trigger \\
      --model qwen2.5-coder:7b --host http://localhost:11434

Optionally supply a packet-defaults file to override timeout/log_path/syntax_check:
  --packet-defaults tests/stage_1_sprint_deliverable/loop_packet.json
""",
    )
    parser.add_argument("--node", required=True)
    parser.add_argument("--campaign-id", required=True)
    parser.add_argument("--budget", required=True, type=int)
    parser.add_argument("--manager", default="baseline_manager")
    parser.add_argument("--memory-mode", default="none")
    parser.add_argument("--records", help="Path to JSONL ledger (default: experiments/ledgers/<campaign-id>_trials.jsonl)")
    parser.add_argument("--tables-dir", default=str(ROOT / "paper" / "tables"))
    parser.add_argument("--dry-run", action="store_true", help="Use mock DryRunWorker; write synthetic TrialRecords.")
    # Real-run args
    parser.add_argument("--node-root", help="Path to the node working directory (required for real runs)")
    parser.add_argument("--artifacts-dir", default=str(ROOT / "experiments" / "artifacts"),
                        help="Where generated packets and trial artifacts are written")
    parser.add_argument("--packet-defaults",
                        help="Optional JSON file whose timeout_seconds/log_path/results_tsv/syntax_check_command "
                             "override node-spec defaults. objective and description are always from the proposal.")
    parser.add_argument("--model", default="qwen2.5-coder:7b")
    parser.add_argument("--host", default="http://localhost:11434")
    parser.add_argument("--temperature", type=float, default=0.7)
    parser.add_argument(
        "--worker-model",
        default=None,
        help=(
            "Worker model id for ClawWorker. Defaults to --model for local providers, "
            "or qwen2.5-coder:7b when --model is a cloud manager provider."
        ),
    )
    parser.add_argument("--worker-host", default=None, help="Worker Ollama-compatible host URL.")
    parser.add_argument(
        "--llm-backend",
        default="native",
        choices=("native", "langchain"),
        help="Proposal backend. native uses --manager; langchain uses LangChainProposalBackend.",
    )
    parser.add_argument("--events", help="Path to campaign event-stream JSONL")
    parser.add_argument("--no-events", action="store_true", help="Disable campaign event stream")
    parser.add_argument(
        "--allow-any-branch",
        action="store_true",
        help="Allow the legacy worker backend to run outside an autoresearch/<tag> branch. Use only for local smoke tests.",
    )
    parser.add_argument(
        "--llm-stub", action="store_true",
        help="Inject a FakeListChatModel into langgraph_manager instead of calling Ollama. "
             "For smoke-testing the LangGraph pipeline without a running LLM.",
    )
    args = parser.parse_args()

    node_spec = load_registered_node(args.node, repo_root=ROOT)
    records_path = (
        Path(args.records)
        if args.records
        else ROOT / "experiments" / "ledgers" / f"{args.campaign_id}_trials.jsonl"
    )
    records_path.parent.mkdir(parents=True, exist_ok=True)
    event_store = None if args.no_events else CampaignEventStore(
        Path(args.events) if args.events else _default_events_path(records_path, args.campaign_id)
    )

    # Resolve the optional stub LLM for LangGraph/LangChain smoke tests.
    manager_llm = None
    if args.llm_stub:
        if args.manager != "langgraph_manager" and args.llm_backend != "langchain":
            parser.error("--llm-stub requires --manager langgraph_manager or --llm-backend langchain")
        from langchain_core.language_models import FakeListChatModel
        import json as _json
        _stub_response = _json.dumps({
            "summary": "reduce-dropout-stub",
            "rationale": "LLM stub for smoke testing — exercises deterministic patch bridge",
            "objective": (
                "In train.py, change DROPOUT from 0.02 to 0.01. "
                "Edit only train.py. Make no other changes."
            ),
            "param": "DROPOUT",
            "old_value": "0.02",
            "new_value": "0.01",
        })
        manager_llm = FakeListChatModel(responses=[_stub_response] * max(args.budget, 1))

    proposal_backend = None
    if args.llm_backend == "langchain":
        proposal_backend = LangChainProposalBackend(
            args.model,
            artifacts_dir=Path(args.artifacts_dir) / args.campaign_id,
            llm=manager_llm,
        )
    elif args.manager == "langgraph_manager":
        from autoresearch.manager.langgraph_manager import LangGraphManager

        proposal_backend = LangGraphManager(
            llm=manager_llm,
            model=args.model,
            host=args.host,
            temperature=args.temperature,
        )

    if args.dry_run:
        result = run_dry_campaign(
            node_spec=node_spec,
            campaign_id=args.campaign_id,
            budget=args.budget,
            manager_mode=args.manager,
            memory_mode=args.memory_mode,
            records_path=records_path,
            manager_llm=manager_llm,
            proposal_backend=proposal_backend,
            event_store=event_store,
        )
    else:
        if not args.node_root:
            parser.error("--node-root is required for real (non-dry-run) campaigns")

        from autoresearch.worker.claw_worker import ClawWorker
        worker_model_id = args.worker_model or _default_worker_model(args.model)
        worker_host_arg = args.worker_host or args.host
        worker_model, worker_host = resolve_worker_model_args(worker_model_id, worker_host_arg)

        if args.packet_defaults:
            worker = ClawWorker.from_packet_defaults_file(
                repo_root=ROOT,
                node_root=args.node_root,
                packet_defaults_path=args.packet_defaults,
                artifacts_dir=args.artifacts_dir,
                model=worker_model,
                host=worker_host,
                allow_any_branch=args.allow_any_branch,
            )
        else:
            worker = ClawWorker(
                repo_root=ROOT,
                node_root=args.node_root,
                artifacts_dir=args.artifacts_dir,
                model=worker_model,
                host=worker_host,
                allow_any_branch=args.allow_any_branch,
            )

        result = run_real_campaign(
            node_spec=node_spec,
            campaign_id=args.campaign_id,
            budget=args.budget,
            manager_mode=args.manager,
            memory_mode=args.memory_mode,
            records_path=records_path,
            worker=worker,
            manager_llm=manager_llm,
            proposal_backend=proposal_backend,
            event_store=event_store,
            manager_temperature=args.temperature,
        )

    summary = load_campaign_summary(
        records_path,
        metric_name=node_spec.metric_name,
        metric_direction=node_spec.metric_direction,
    )
    table_outputs = export_campaign_tables(summary, args.tables_dir)
    print(
        json.dumps(
            {
                "campaign": result.to_dict(),
                "metrics": summary.metrics.to_dict(),
                "tables": {key: str(path) for key, path in table_outputs.items()},
                "events": None if event_store is None else str(event_store.path),
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


def _default_events_path(records_path: Path, campaign_id: str) -> Path:
    root = records_path.parent.parent if records_path.parent.name == "ledgers" else records_path.parent
    return root / "events" / f"{campaign_id}_events.jsonl"


def _default_worker_model(manager_model: str) -> str:
    if manager_model.startswith(("openai/", "anthropic/", "deepseek/")):
        return "qwen2.5-coder:7b"
    return manager_model


if __name__ == "__main__":
    raise SystemExit(main())
